# Variablen
$InBucket = "face-recognition-in"
$OutBucket = "face-recognition-out"
$TestImage = ".\Test.jpg"
$OutputJson = ".\$($TestImage).json"

Write-Host "=== Erkennung bekannter Persönlichkeit auf Foto ==="

Write-Host "Lade das Bild der Persönlichkeit hoch..."
Write-S3Object -BucketName $InBucket -File $TestImage -Key $TestImage

Write-Host "Warte 10 Sekunden auf Verarbeitung..."
Start-Sleep -Seconds 10

Write-Host "Lade Ergebnis herunter..."
Read-S3Object -BucketName $OutBucket -Key "$($TestImage).json" -File $OutputJson

Write-Host "=== Erkanntes Ergebnis ==="
Get-Content $OutputJson

Write-Host "=== Test abgeschlossen ==="
