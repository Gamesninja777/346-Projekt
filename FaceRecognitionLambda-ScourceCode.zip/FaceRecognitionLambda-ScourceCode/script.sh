#!/bin/bash

# === Variablen ===
REGION="us-east-1"
IN_BUCKET="face-recognition-in"
OUT_BUCKET="face-recognition-out"
LAMBDA_NAME="FaceRecognitionFunction"
ZIP_FILE="FaceRecognitionLambda.zip"
ROLE="LabRole"
HANDLER="FaceRecognitionLambda::FaceRecognitionLambda.Function::Handler"
TEST_IMAGE="Test.jpg"
OUTPUT_JSON="$TEST_IMAGE.json"

echo "=== FaceRecognition Service Deployment ==="

# 1️⃣ Prüfe / erstelle S3 Buckets
for bucket in $IN_BUCKET $OUT_BUCKET; do
    if ! aws s3 ls s3://$bucket 2>/dev/null; then
        echo "Erstelle Bucket: $bucket"
        aws s3 mb s3://$bucket --region $REGION
    else
        echo "Bucket existiert bereits: $bucket"
    fi
done

# 2️⃣ Prüfe / erstelle oder update Lambda Funktion
if ! aws lambda get-function --function-name $LAMBDA_NAME >/dev/null 2>&1; then
    echo "Lambda-Funktion existiert nicht → erstelle..."
    aws lambda create-function \
        --function-name $LAMBDA_NAME \
        --runtime dotnet8 \
        --role arn:aws:iam::851725539512:role/$ROLE \
        --handler $HANDLER \
        --zip-file fileb://$ZIP_FILE \
        --timeout 30 \
        --memory-size 512
else
    # Prüfen ob Code sich geändert hat
    LOCAL_HASH=$(sha256sum $ZIP_FILE | awk '{print $1}')
    REMOTE_HASH=$(aws lambda get-function --function-name $LAMBDA_NAME --query 'Configuration.CodeSha256' --output text)
    
    if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]; then
        echo "Code hat sich geändert → update Lambda..."
        aws lambda update-function-code --function-name $LAMBDA_NAME --zip-file fileb://$ZIP_FILE
    else
        echo "Lambda existiert → Code ist aktuell, kein Update nötig."
    fi
fi

# 3️⃣ S3 Trigger setzen
LAMBDA_ARN=$(aws lambda get-function --function-name $LAMBDA_NAME --query 'Configuration.FunctionArn' --output text)
aws s3api put-bucket-notification-configuration \
    --bucket $IN_BUCKET \
    --notification-configuration "{\"LambdaFunctionConfigurations\":[{\"LambdaFunctionArn\":\"$LAMBDA_ARN\",\"Events\":[\"s3:ObjectCreated:Put\"]}]}"

echo "=== Deployment abgeschlossen ==="

# 4️⃣ Test Upload
echo "=== Test Upload ==="
aws s3 cp $TEST_IMAGE s3://$IN_BUCKET/ --region $REGION

# 5️⃣ Warten + JSON herunterladen
echo "Warte 10 Sekunden auf Lambda-Verarbeitung..."
sleep 10

aws s3 cp s3://$OUT_BUCKET/${TEST_IMAGE}.json ./$OUTPUT_JSON --region $REGION
echo "=== Ergebnis JSON ==="
cat $OUTPUT_JSON

echo "=== Ende der Erkennung ==="
