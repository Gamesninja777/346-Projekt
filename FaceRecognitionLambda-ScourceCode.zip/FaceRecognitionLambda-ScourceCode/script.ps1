# =====================================
# FaceRecognition Init + Test (PowerShell)
# =====================================

# Variablen
$Region = "us-east-1"
$InBucket = "face-recognition-in"
$OutBucket = "face-recognition-out"
$LambdaName = "FaceRecognitionFunction"
$LambdaZipPath = ".\FaceRecognitionLambda.zip"
$LambdaRole = "LabRole"
$Handler = "FaceRecognitionLambda::FaceRecognitionLambda.Function::Handler"
$TestImage = ".\Test.jpg"
$OutputJson = ".\$($TestImage).json"

# AWS Module prüfen
if (-not (Get-Module -ListAvailable -Name AWSPowerShell.NetCore)) {
    Write-Host "Installiere AWSPowerShell.NetCore..."
    Install-Module -Name AWSPowerShell.NetCore -Scope CurrentUser -Force
}

Import-Module AWSPowerShell.NetCore

Write-Host "=== FaceRecognition Service Deployment ==="

# 1️⃣ S3 Buckets prüfen/erstellen
foreach ($bucket in @($InBucket, $OutBucket)) {
    if (-not (Get-S3Bucket -BucketName $bucket -ErrorAction SilentlyContinue)) {
        Write-Host "Erstelle Bucket: $bucket"
        New-S3Bucket -BucketName $bucket -Region $Region
    } else {
        Write-Host "Bucket existiert bereits: $bucket"
    }
}

# 2️⃣ Lambda Funktion prüfen/erstellen/aktualisieren
$lambda = Get-LMFunction -FunctionName $LambdaName -ErrorAction SilentlyContinue

if ($lambda) {
    # Prüfen ob Code aktualisiert werden muss
    $localHash = [System.Convert]::ToBase64String((Get-FileHash $LambdaZipPath -Algorithm SHA256).Hash)
    $remoteHash = $lambda.Configuration.CodeSha256

    if ($localHash -ne $remoteHash) {
        Write-Host "Code hat sich geändert → update Lambda..."
        Update-LMFunctionCode -FunctionName $LambdaName -ZipFile $LambdaZipPath
    } else {
        Write-Host "Lambda existiert → Code ist aktuell, kein Update nötig."
    }
} else {
    Write-Host "Lambda existiert nicht → erstelle..."
    New-LMFunction -FunctionName $LambdaName `
                   -Runtime dotnet8 `
                   -Role $LambdaRole `
                   -Handler $Handler `
                   -Code_ZipFile $LambdaZipPath `
                   -Timeout 30 `
                   -MemorySize 512
}

# 3️⃣ S3 Trigger erstellen
$lambda = Get-LMFunction -FunctionName $LambdaName
$triggerConfig = @{
    LambdaFunctionConfigurations = @(@{
        LambdaFunctionArn = $lambda.Configuration.FunctionArn
        Events = @("s3:ObjectCreated:Put")
    })
}
Write-S3BucketNotification -BucketName $InBucket -NotificationConfiguration $triggerConfig

Write-Host "=== Deployment abgeschlossen ==="

# 4️⃣ Test Upload
Write-Host "=== Test Upload ==="
Write-S3Object -BucketName $InBucket -File $TestImage -Key (Split-Path $TestImage -Leaf)

# 5️⃣ Warten + JSON herunterladen
Write-Host "Warte 10 Sekunden auf Lambda-Verarbeitung..."
Start-Sleep -Seconds 10

Read-S3Object -BucketName $OutBucket -Key (Split-Path $TestImage -Leaf + ".json") -File $OutputJson

Write-Host "=== Ergebnis JSON ==="
Get-Content $OutputJson

Write-Host "=== Test abgeschlossen ==="
