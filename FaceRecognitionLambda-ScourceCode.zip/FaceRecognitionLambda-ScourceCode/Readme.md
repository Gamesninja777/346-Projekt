# AWS Lambda Bilderkennung Projekt

Das Projekt FaceRecognitionLambda besteht aus:

- FaceRecognitionLambda.zip: eine ZIP-Datei, die den Code enthält
- init.sh: ein Script zur Initialisierung
- Test.jpg: ein Bild für Testzwecke

## Über das Projekt

## Wie funktioniert das:

## Worauf soll beachtet wird:

- Bildname
- Bildgrösse (Gemäss dem Lehrer)

## Script ausführen

```
chmod +x init.sh
```

```
./init.sh

```
