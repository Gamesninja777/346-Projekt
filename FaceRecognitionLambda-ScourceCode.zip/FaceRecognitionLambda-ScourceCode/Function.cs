using Amazon.Lambda.Core;
using Amazon.Lambda.S3Events;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.Rekognition;
using Amazon.Rekognition.Model;
using System.Text.Json;
using System.Text;

[assembly: LambdaSerializer(typeof(Amazon.Lambda.Serialization.SystemTextJson.DefaultLambdaJsonSerializer))]

/// <summary>
/// Gem�ss dem Projektauftrag wurde der Code so geschrieben, dass er zuerst das Bild aus dem In-Bucket abruft.
/// Danach wird die Pers�nlichkeit auf dem Bild mittels Amazon Rekognition erkannt.
/// Die Informationen �ber diese erkannte Pers�nlichkeit sowie deren Name werden als JSON-Datei im Out-Bucket abgelegt.
/// Forscher und Autor: Mohammad Mohammady
/// Kontrolle: Tom R�dis�li, Finn M�ller
/// Beginn: 03.12.2025
/// Ende: 17.12.2025
/// Quellen:
/// - AWS Rekognition � Recognizing Celebrities  
/// https://docs.aws.amazon.com/rekognition/latest/dg/celebrities.html
/// -AWS Lambda mit S3 Trigger  
/// https://docs.aws.amazon.com/lambda/latest/dg/with-s3.html
/// -AWS CLI Referenz(S3 & Lambda)
/// https://docs.aws.amazon.com/cli/latest/reference/
/// -AWS IAM Rollen  
/// https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles.html
/// </summary>
namespace FaceRecognitionLambda
{
    /// <summary>
    /// AWS-Lambda-Funktion zur Gesichtserkennung einer bekannten Pers�nlichkeit mit Amazon Rekognition.
    /// </summary>
    public class Function
    {
        private readonly IAmazonS3 _s3 = new AmazonS3Client();
        private readonly IAmazonRekognition _rekognition = new AmazonRekognitionClient();

        /// <summary>
        /// Wird durch ein S3-Upload-Ereignis ausgel�st und verarbeitet ein Bild.
        /// </summary>
        public async Task Handler(S3Event evnt, ILambdaContext context)
        {
            try
            {
                var record = evnt.Records[0];
                var inBucket = record.S3.Bucket.Name; // Der Name des Buckets, in den das Bild hingestellt wird.
                var outBucket = inBucket.Replace("-in", "-out"); // Der Name des Buckets, in den die JSON-Datei hingestellt wird.
                var key = System.Net.WebUtility.UrlDecode(record.S3.Object.Key);

                context.Logger.LogInformation($"Processing image: {inBucket}/{key}");

                /// <summary>
                /// F�hrt eine Prominenten-Erkennung auf das hochgeladene Bild durch.
                /// </summary>
                var rekResponse = await _rekognition.RecognizeCelebritiesAsync(
                    new RecognizeCelebritiesRequest
                    {
                        Image = new Amazon.Rekognition.Model.Image
                        {
                            S3Object = new Amazon.Rekognition.Model.S3Object
                            {
                                Bucket = inBucket,
                                Name = key
                            }
                        }
                    });

                /// <summary>
                /// Erstellt das Ergebnisobjekt mit Erkennungsdaten und Metainformationen.
                /// </summary>
                var result = new
                {
                    SourceImage = $"{inBucket}/{key}",
                    Timestamp = DateTime.UtcNow,
                    Celebrities = rekResponse.CelebrityFaces.Select(c => new
                    {
                        c.Name,
                        c.Id,
                        Confidence = c.MatchConfidence,
                        c.Urls,
                        BoundingBox = c.Face?.BoundingBox
                    }),
                    UnrecognizedFaces = rekResponse.UnrecognizedFaces.Count
                };

                string json = JsonSerializer.Serialize(result, new JsonSerializerOptions
                {
                    WriteIndented = true
                });

                byte[] bytes = Encoding.UTF8.GetBytes(json);
                string outputKey = key + ".json";

                /// <summary>
                /// Speichert das Analyseergebnis als JSON-Datei im Ziel-S3-Bucket.
                /// </summary>
                await _s3.PutObjectAsync(new PutObjectRequest
                {
                    BucketName = outBucket,
                    Key = outputKey,
                    InputStream = new MemoryStream(bytes),
                    ContentType = "application/json"
                });

                context.Logger.LogInformation($"Saved JSON: {outBucket}/{outputKey}");
            }
            catch (Exception ex)
            {
                context.Logger.LogError($"Error: {ex.Message}");
            }
        }
    }
}
