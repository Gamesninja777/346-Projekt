#!/bin/bash

# Variablen
REGION="us-east-1"
IN_BUCKET="face-recognition-in"
OUT_BUCKET="face-recognition-out"
TEST_IMAGE="Test.jpg"
OUTPUT_JSON="$TEST_IMAGE.json"

echo "=== Erkennung bekannter Persönlichkeit aus Foto ==="

echo "Lade das Bild hoch..."
aws s3 cp "$TEST_IMAGE" "s3://$IN_BUCKET/" --region "$REGION"

echo "Warte 10 Sekunden auf Verarbeitung..."
sleep 10

echo "Lade Ergebnis herunter..."
aws s3 cp "s3://$OUT_BUCKET/${TEST_IMAGE}.json" "$OUTPUT_JSON" --region "$REGION"

echo "=== Erkanntes Ergebnis ==="
cat "$OUTPUT_JSON"

echo "=== Ende der Erkennung ==="
